"""
# Qiskit Export

## QAOA Rapid Quantum Prototyping by qubit-lab.ch

This file was generated from a pre-optimized Excel use case. It reconstructs the final optimized QAOA circuit from the exported Ising coefficients and optimized angle parameters.

## Intended Use

- Technical review
- Reproducibility checks
- Further experimentation outside the RQP web interface

## Run Summary
- Fixed positions: 24
- Variable positions / qubits: 16
- Budget: 3,200,000
- Budget penalty lambda: 50
- Variance penalty lambda: 6
- QAOA layers: 4
- Shots mode: exact
- Candidate export cap: n/a
- Candidate export sort: n/a
- Restarts: 2
- Optimizer iterations: 60
- Warm start: True
- Random seed: 42
- Additional subtype budgets: 0

## Expected Dependencies

- qiskit
- numpy
- matplotlib (optional, for plots)
- qiskit-ibm-runtime (optional IBM hardware cell)

Copyright (c) qubit-lab.ch.

Legal terms: https://qubit-lab.ch/legal
"""

# Cell purpose: load the self-contained export package used by all later cells.
# It contains the pre-optimized use case parameters, Ising terms,
# optimized QAOA angles, fixed and variable assets, covariance data,
# subtype budgets, bit-order metadata, and decision-variable labels.
import json

PACKAGE = json.loads(r'''
{
  "assets": {
    "fixed_assets": [
      {
        "annual_volatility": 0.2366690061065773,
        "company": "Microsoft",
        "decision_id": "FIX_01",
        "decision_role": "fixed",
        "expected_return_proxy": -0.01958470396936385,
        "index": 0,
        "indicative_market_cost_usd": 100163.7985229492,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 242,
        "ticker": "MSFT",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2384966594298212,
        "company": "Apple",
        "decision_id": "FIX_02",
        "decision_role": "fixed",
        "expected_return_proxy": 0.3349228092184238,
        "index": 1,
        "indicative_market_cost_usd": 100086.0895690918,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 353,
        "ticker": "AAPL",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3388273581486801,
        "company": "NVIDIA",
        "decision_id": "FIX_03",
        "decision_role": "fixed",
        "expected_return_proxy": 0.7826527491472257,
        "index": 2,
        "indicative_market_cost_usd": 100054.2416229248,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 503,
        "ticker": "NVDA",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2994451448364812,
        "company": "Alphabet",
        "decision_id": "FIX_04",
        "decision_role": "fixed",
        "expected_return_proxy": 1.393391458938255,
        "index": 3,
        "indicative_market_cost_usd": 100027.2003173828,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 260,
        "ticker": "GOOGL",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3070572516128711,
        "company": "Amazon",
        "decision_id": "FIX_05",
        "decision_role": "fixed",
        "expected_return_proxy": 0.4119086106021952,
        "index": 4,
        "indicative_market_cost_usd": 99898.74499511719,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 372,
        "ticker": "AMZN",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3598809540274538,
        "company": "Meta Platforms",
        "decision_id": "FIX_06",
        "decision_role": "fixed",
        "expected_return_proxy": 0.072576068389969,
        "index": 5,
        "indicative_market_cost_usd": 99728.29278564453,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 163,
        "ticker": "META",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4250376051836972,
        "company": "Broadcom",
        "decision_id": "FIX_07",
        "decision_role": "fixed",
        "expected_return_proxy": 1.146521146485912,
        "index": 6,
        "indicative_market_cost_usd": 100000.1290893555,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 238,
        "ticker": "AVGO",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3144322683839252,
        "company": "Adobe",
        "decision_id": "FIX_08",
        "decision_role": "fixed",
        "expected_return_proxy": -0.3302226252529759,
        "index": 7,
        "indicative_market_cost_usd": 100116.5617675781,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 399,
        "ticker": "ADBE",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3471019016668514,
        "company": "Salesforce",
        "decision_id": "FIX_09",
        "decision_role": "fixed",
        "expected_return_proxy": -0.3161948856117062,
        "index": 8,
        "indicative_market_cost_usd": 99994.33099365234,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 547,
        "ticker": "CRM",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3878929904972673,
        "company": "ASML",
        "decision_id": "FIX_10",
        "decision_role": "fixed",
        "expected_return_proxy": 1.169058687729406,
        "index": 9,
        "indicative_market_cost_usd": 100443.7023925781,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 70,
        "ticker": "ASML",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.6017217223258714,
        "company": "Advanced Micro Devices",
        "decision_id": "FIX_11",
        "decision_role": "fixed",
        "expected_return_proxy": 2.700051523080516,
        "index": 10,
        "indicative_market_cost_usd": 100130.7958984375,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 280,
        "ticker": "AMD",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3511103843573644,
        "company": "TSMC",
        "decision_id": "FIX_12",
        "decision_role": "fixed",
        "expected_return_proxy": 1.334430055119907,
        "index": 11,
        "indicative_market_cost_usd": 99965.76724243164,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 251,
        "ticker": "TSM",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3613874176295283,
        "company": "Qualcomm",
        "decision_id": "FIX_13",
        "decision_role": "fixed",
        "expected_return_proxy": 0.3372492494157311,
        "index": 12,
        "indicative_market_cost_usd": 99995.21896362305,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 566,
        "ticker": "QCOM",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.682363141557847,
        "company": "Intel",
        "decision_id": "FIX_14",
        "decision_role": "fixed",
        "expected_return_proxy": 3.980980927086012,
        "index": 13,
        "indicative_market_cost_usd": 100017.5966262817,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 1005,
        "ticker": "INTC",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.5916973892624385,
        "company": "Micron Technology",
        "decision_id": "FIX_15",
        "decision_role": "fixed",
        "expected_return_proxy": 5.867692097100164,
        "index": 14,
        "indicative_market_cost_usd": 100171.1022949219,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 188,
        "ticker": "MU",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.6210855080108111,
        "company": "Oracle",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": 0.20323656834096,
        "index": 15,
        "indicative_market_cost_usd": 100005.6442260742,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 577,
        "ticker": "ORCL",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4277138651927239,
        "company": "ServiceNow",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": -0.527871999791017,
        "index": 16,
        "indicative_market_cost_usd": 100043.2320251465,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 1106,
        "ticker": "NOW",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.5214468112403083,
        "company": "Snowflake",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": -0.1548748628891321,
        "index": 17,
        "indicative_market_cost_usd": 100060.9235229492,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 716,
        "ticker": "SNOW",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.547111796133451,
        "company": "Datadog",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": 0.3213883173101935,
        "index": 18,
        "indicative_market_cost_usd": 100028.8839111328,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 712,
        "ticker": "DDOG",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.6821563231515669,
        "company": "MongoDB",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": 0.5164643208948372,
        "index": 19,
        "indicative_market_cost_usd": 100008.9581298828,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 383,
        "ticker": "MDB",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3456206183233314,
        "company": "Palo Alto Networks",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": -0.02168899152980353,
        "index": 20,
        "indicative_market_cost_usd": 100044.2676544189,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 549,
        "ticker": "PANW",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4217188713286705,
        "company": "CrowdStrike",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": 0.05294292390447497,
        "index": 21,
        "indicative_market_cost_usd": 100043.8989257812,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 220,
        "ticker": "CRWD",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4505884714006745,
        "company": "Zscaler",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": -0.3885316751927542,
        "index": 22,
        "indicative_market_cost_usd": 99964.79736328125,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 720,
        "ticker": "ZS",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.392764188750546,
        "company": "Fortinet",
        "decision_id": "FIX_16",
        "decision_role": "fixed",
        "expected_return_proxy": -0.1743546916603711,
        "index": 23,
        "indicative_market_cost_usd": 99979.05731201172,
        "option_label": "fixed_100k",
        "role": "fixed",
        "shares": 1162,
        "ticker": "FTNT",
        "type_sizes": {}
      }
    ],
    "variable_assets": [
      {
        "annual_volatility": 0.5155448186879324,
        "company": "Cloudflare",
        "decision_id": "VAR_01",
        "decision_role": "variable",
        "expected_return_proxy": 0.7530380994326458,
        "index": 0,
        "indicative_market_cost_usd": 99947.1011352539,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 465,
        "ticker": "NET",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.220020989162983,
        "company": "Visa",
        "decision_id": "VAR_02",
        "decision_role": "variable",
        "expected_return_proxy": -0.01955289281018346,
        "index": 1,
        "indicative_market_cost_usd": 99978.0029296875,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 300,
        "ticker": "V",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.21779975820074,
        "company": "Mastercard",
        "decision_id": "VAR_03",
        "decision_role": "variable",
        "expected_return_proxy": -0.0851092757313362,
        "index": 2,
        "indicative_market_cost_usd": 99931.17269897461,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 201,
        "ticker": "MA",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3854516427918045,
        "company": "PayPal",
        "decision_id": "VAR_04",
        "decision_role": "variable",
        "expected_return_proxy": -0.222666395554225,
        "index": 3,
        "indicative_market_cost_usd": 99986.7765083313,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1977,
        "ticker": "PYPL",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.5689358872467991,
        "company": "Fiserv",
        "decision_id": "VAR_05",
        "decision_role": "variable",
        "expected_return_proxy": -0.6576603796488678,
        "index": 4,
        "indicative_market_cost_usd": 99997.37805175781,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1596,
        "ticker": "FISV",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2836661789738265,
        "company": "FIS",
        "decision_id": "VAR_06",
        "decision_role": "variable",
        "expected_return_proxy": -0.3809459790693239,
        "index": 5,
        "indicative_market_cost_usd": 99990.80325317383,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 2132,
        "ticker": "FIS",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2592710501947953,
        "company": "Equinix",
        "decision_id": "VAR_07",
        "decision_role": "variable",
        "expected_return_proxy": 0.2871641105032321,
        "index": 6,
        "indicative_market_cost_usd": 99760.39990234375,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 92,
        "ticker": "EQIX",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2168734281571604,
        "company": "Digital Realty",
        "decision_id": "VAR_08",
        "decision_role": "variable",
        "expected_return_proxy": 0.2787981688159535,
        "index": 7,
        "indicative_market_cost_usd": 99969.06712341309,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 497,
        "ticker": "DLR",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2339534149407814,
        "company": "American Tower",
        "decision_id": "VAR_09",
        "decision_role": "variable",
        "expected_return_proxy": -0.1560760195710867,
        "index": 8,
        "indicative_market_cost_usd": 99919.58367919922,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 548,
        "ticker": "AMT",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2625437627788479,
        "company": "Crown Castle",
        "decision_id": "VAR_10",
        "decision_role": "variable",
        "expected_return_proxy": -0.1142125295776206,
        "index": 9,
        "indicative_market_cost_usd": 99991.03796386719,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1112,
        "ticker": "CCI",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.2557683899515204,
        "company": "Cisco",
        "decision_id": "VAR_11",
        "decision_role": "variable",
        "expected_return_proxy": 0.6251755689414027,
        "index": 10,
        "indicative_market_cost_usd": 99993.39198303223,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1083,
        "ticker": "CSCO",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.5491197900652892,
        "company": "Shopify",
        "decision_id": "VAR_12",
        "decision_role": "variable",
        "expected_return_proxy": 0.2963611933502133,
        "index": 11,
        "indicative_market_cost_usd": 99979.20169830322,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 795,
        "ticker": "SHOP",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3243828016878402,
        "company": "Uber",
        "decision_id": "VAR_13",
        "decision_role": "variable",
        "expected_return_proxy": -0.07516382589851711,
        "index": 12,
        "indicative_market_cost_usd": 100020.9667358398,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1337,
        "ticker": "UBER",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4391913084085376,
        "company": "Spotify",
        "decision_id": "VAR_14",
        "decision_role": "variable",
        "expected_return_proxy": -0.2666082792800718,
        "index": 13,
        "indicative_market_cost_usd": 99822.50610351562,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 226,
        "ticker": "SPOT",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.3713331140722419,
        "company": "MercadoLibre",
        "decision_id": "VAR_15",
        "decision_role": "variable",
        "expected_return_proxy": -0.1993706557552525,
        "index": 14,
        "indicative_market_cost_usd": 99201.2431640625,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 54,
        "ticker": "MELI",
        "type_sizes": {}
      },
      {
        "annual_volatility": 0.4845305710160809,
        "company": "Sea Limited",
        "decision_id": "VAR_16",
        "decision_role": "variable",
        "expected_return_proxy": -0.3760104739014806,
        "index": 15,
        "indicative_market_cost_usd": 99988.56035614014,
        "option_label": "new_100k",
        "role": "variable",
        "shares": 1167,
        "ticker": "SE",
        "type_sizes": {}
      }
    ]
  },
  "bit_order": {
    "counts_decoder": "reverse_qiskit_count_key",
    "optimizer_bitstring_order": "q0...qN-1",
    "qiskit_counts_key_order": "cN-1...c0"
  },
  "decision_variables": [
    {
      "annual_volatility": 0.5155448186879324,
      "company": "Cloudflare",
      "decision_id": "VAR_01",
      "decision_role": "variable",
      "expected_return_proxy": 0.7530380994326458,
      "index": 0,
      "indicative_market_cost_usd": 99947.1011352539,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 465,
      "ticker": "NET",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.220020989162983,
      "company": "Visa",
      "decision_id": "VAR_02",
      "decision_role": "variable",
      "expected_return_proxy": -0.01955289281018346,
      "index": 1,
      "indicative_market_cost_usd": 99978.0029296875,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 300,
      "ticker": "V",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.21779975820074,
      "company": "Mastercard",
      "decision_id": "VAR_03",
      "decision_role": "variable",
      "expected_return_proxy": -0.0851092757313362,
      "index": 2,
      "indicative_market_cost_usd": 99931.17269897461,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 201,
      "ticker": "MA",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.3854516427918045,
      "company": "PayPal",
      "decision_id": "VAR_04",
      "decision_role": "variable",
      "expected_return_proxy": -0.222666395554225,
      "index": 3,
      "indicative_market_cost_usd": 99986.7765083313,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1977,
      "ticker": "PYPL",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.5689358872467991,
      "company": "Fiserv",
      "decision_id": "VAR_05",
      "decision_role": "variable",
      "expected_return_proxy": -0.6576603796488678,
      "index": 4,
      "indicative_market_cost_usd": 99997.37805175781,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1596,
      "ticker": "FISV",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2836661789738265,
      "company": "FIS",
      "decision_id": "VAR_06",
      "decision_role": "variable",
      "expected_return_proxy": -0.3809459790693239,
      "index": 5,
      "indicative_market_cost_usd": 99990.80325317383,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 2132,
      "ticker": "FIS",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2592710501947953,
      "company": "Equinix",
      "decision_id": "VAR_07",
      "decision_role": "variable",
      "expected_return_proxy": 0.2871641105032321,
      "index": 6,
      "indicative_market_cost_usd": 99760.39990234375,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 92,
      "ticker": "EQIX",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2168734281571604,
      "company": "Digital Realty",
      "decision_id": "VAR_08",
      "decision_role": "variable",
      "expected_return_proxy": 0.2787981688159535,
      "index": 7,
      "indicative_market_cost_usd": 99969.06712341309,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 497,
      "ticker": "DLR",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2339534149407814,
      "company": "American Tower",
      "decision_id": "VAR_09",
      "decision_role": "variable",
      "expected_return_proxy": -0.1560760195710867,
      "index": 8,
      "indicative_market_cost_usd": 99919.58367919922,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 548,
      "ticker": "AMT",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2625437627788479,
      "company": "Crown Castle",
      "decision_id": "VAR_10",
      "decision_role": "variable",
      "expected_return_proxy": -0.1142125295776206,
      "index": 9,
      "indicative_market_cost_usd": 99991.03796386719,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1112,
      "ticker": "CCI",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.2557683899515204,
      "company": "Cisco",
      "decision_id": "VAR_11",
      "decision_role": "variable",
      "expected_return_proxy": 0.6251755689414027,
      "index": 10,
      "indicative_market_cost_usd": 99993.39198303223,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1083,
      "ticker": "CSCO",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.5491197900652892,
      "company": "Shopify",
      "decision_id": "VAR_12",
      "decision_role": "variable",
      "expected_return_proxy": 0.2963611933502133,
      "index": 11,
      "indicative_market_cost_usd": 99979.20169830322,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 795,
      "ticker": "SHOP",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.3243828016878402,
      "company": "Uber",
      "decision_id": "VAR_13",
      "decision_role": "variable",
      "expected_return_proxy": -0.07516382589851711,
      "index": 12,
      "indicative_market_cost_usd": 100020.9667358398,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1337,
      "ticker": "UBER",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.4391913084085376,
      "company": "Spotify",
      "decision_id": "VAR_14",
      "decision_role": "variable",
      "expected_return_proxy": -0.2666082792800718,
      "index": 13,
      "indicative_market_cost_usd": 99822.50610351562,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 226,
      "ticker": "SPOT",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.3713331140722419,
      "company": "MercadoLibre",
      "decision_id": "VAR_15",
      "decision_role": "variable",
      "expected_return_proxy": -0.1993706557552525,
      "index": 14,
      "indicative_market_cost_usd": 99201.2431640625,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 54,
      "ticker": "MELI",
      "type_sizes": {}
    },
    {
      "annual_volatility": 0.4845305710160809,
      "company": "Sea Limited",
      "decision_id": "VAR_16",
      "decision_role": "variable",
      "expected_return_proxy": -0.3760104739014806,
      "index": 15,
      "indicative_market_cost_usd": 99988.56035614014,
      "option_label": "new_100k",
      "role": "variable",
      "shares": 1167,
      "ticker": "SE",
      "type_sizes": {}
    }
  ],
  "generator": {
    "legal_url": "https://qubit-lab.ch/legal",
    "model_version": "9.2.0",
    "organization": "qubit-lab.ch",
    "service": "qaoa-rqp-api-v9",
    "tool": "QAOA Rapid Quantum Prototyping"
  },
  "ising": {
    "h_terms": [
      -0.025585757660120965,
      -0.006381449732818154,
      -0.006200431563986766,
      -0.017636080063022763,
      -0.015019616836039165,
      -0.01086521251192225,
      -0.003272593493748484,
      -0.006391387417281704,
      0.0012807736263804118,
      -0.0015410312050464572,
      -0.006374474550474161,
      -0.029440202324518265,
      -0.013772649659059666,
      -0.013550718976927428,
      -0.015192444050549116,
      -0.019798383443281952
    ],
    "j_terms": [
      [
        0,
        1,
        0.024464323777704224
      ],
      [
        0,
        2,
        0.024458764024943232
      ],
      [
        0,
        3,
        0.024688542354720885
      ],
      [
        0,
        4,
        0.0246408091683127
      ],
      [
        0,
        5,
        0.024575220770040956
      ],
      [
        0,
        6,
        0.024405531950032304
      ],
      [
        0,
        7,
        0.02454281400854992
      ],
      [
        0,
        8,
        0.02427397363787956
      ],
      [
        0,
        9,
        0.024367684354491007
      ],
      [
        0,
        10,
        0.0245666405116337
      ],
      [
        0,
        11,
        0.025147157502157392
      ],
      [
        0,
        12,
        0.024721497929423488
      ],
      [
        0,
        13,
        0.024763701935395736
      ],
      [
        0,
        14,
        0.024524604808845232
      ],
      [
        0,
        15,
        0.02474020651636712
      ],
      [
        1,
        2,
        0.024651362532149012
      ],
      [
        1,
        3,
        0.024602920053910165
      ],
      [
        1,
        4,
        0.02461140875175102
      ],
      [
        1,
        5,
        0.024582371925911818
      ],
      [
        1,
        6,
        0.024407394831202835
      ],
      [
        1,
        7,
        0.02442956838161239
      ],
      [
        1,
        8,
        0.02441368079467079
      ],
      [
        1,
        9,
        0.02444250486723812
      ],
      [
        1,
        10,
        0.024481411975906232
      ],
      [
        1,
        11,
        0.024630898902095893
      ],
      [
        1,
        12,
        0.024513366121620125
      ],
      [
        1,
        13,
        0.02449835680681886
      ],
      [
        1,
        14,
        0.024309691060105564
      ],
      [
        1,
        15,
        0.02451370917137343
      ],
      [
        2,
        3,
        0.02457078282289169
      ],
      [
        2,
        4,
        0.024622529737120057
      ],
      [
        2,
        5,
        0.02457497040060005
      ],
      [
        2,
        6,
        0.024382160672570402
      ],
      [
        2,
        7,
        0.02440620471475552
      ],
      [
        2,
        8,
        0.024392199303918578
      ],
      [
        2,
        9,
        0.02441765426260084
      ],
      [
        2,
        10,
        0.024463551700325627
      ],
      [
        2,
        11,
        0.024638111574112446
      ],
      [
        2,
        12,
        0.024525091380021357
      ],
      [
        2,
        13,
        0.024462686258277848
      ],
      [
        2,
        14,
        0.024295779177511804
      ],
      [
        2,
        15,
        0.02447690879846909
      ],
      [
        3,
        4,
        0.02490007715808784
      ],
      [
        3,
        5,
        0.02477182989965045
      ],
      [
        3,
        6,
        0.02442213622101876
      ],
      [
        3,
        7,
        0.024466609700750968
      ],
      [
        3,
        8,
        0.024452647640610524
      ],
      [
        3,
        9,
        0.02450862984495645
      ],
      [
        3,
        10,
        0.02450566153013547
      ],
      [
        3,
        11,
        0.025003409177530654
      ],
      [
        3,
        12,
        0.024651566927199758
      ],
      [
        3,
        13,
        0.024691312696335264
      ],
      [
        3,
        14,
        0.024478913357702064
      ],
      [
        3,
        15,
        0.024654298258638144
      ],
      [
        4,
        5,
        0.02484283571350634
      ],
      [
        4,
        6,
        0.02445346556684316
      ],
      [
        4,
        7,
        0.024537808727365953
      ],
      [
        4,
        8,
        0.024462015059249678
      ],
      [
        4,
        9,
        0.024559587939704208
      ],
      [
        4,
        10,
        0.024499222838219686
      ],
      [
        4,
        11,
        0.024781393380480164
      ],
      [
        4,
        12,
        0.024593575453036406
      ],
      [
        4,
        13,
        0.02451534953073744
      ],
      [
        4,
        14,
        0.02436897008549769
      ],
      [
        4,
        15,
        0.024611349334006796
      ],
      [
        5,
        6,
        0.0244023853608714
      ],
      [
        5,
        7,
        0.02443819622235248
      ],
      [
        5,
        8,
        0.024444084260522993
      ],
      [
        5,
        9,
        0.02448953422019491
      ],
      [
        5,
        10,
        0.024477256723820923
      ],
      [
        5,
        11,
        0.024701806871363946
      ],
      [
        5,
        12,
        0.024520768601484638
      ],
      [
        5,
        13,
        0.02454806318845496
      ],
      [
        5,
        14,
        0.024340589873354624
      ],
      [
        5,
        15,
        0.024614844076344254
      ],
      [
        6,
        7,
        0.024556939978172175
      ],
      [
        6,
        8,
        0.02445724370837371
      ],
      [
        6,
        9,
        0.024484753040351637
      ],
      [
        6,
        10,
        0.024321738714587995
      ],
      [
        6,
        11,
        0.024383812230928583
      ],
      [
        6,
        12,
        0.024415774749005498
      ],
      [
        6,
        13,
        0.024229393502347287
      ],
      [
        6,
        14,
        0.02420678241830656
      ],
      [
        6,
        15,
        0.024374347758928078
      ],
      [
        7,
        8,
        0.024479570768155986
      ],
      [
        7,
        9,
        0.02453353535473518
      ],
      [
        7,
        10,
        0.024452038266088136
      ],
      [
        7,
        11,
        0.024530494538590412
      ],
      [
        7,
        12,
        0.024489365601986446
      ],
      [
        7,
        13,
        0.024338736570156564
      ],
      [
        7,
        14,
        0.024289917460836075
      ],
      [
        7,
        15,
        0.024491120383576682
      ],
      [
        8,
        9,
        0.02470898426109101
      ],
      [
        8,
        10,
        0.02434358462544431
      ],
      [
        8,
        11,
        0.02432300175182213
      ],
      [
        8,
        12,
        0.024372602011374315
      ],
      [
        8,
        13,
        0.024399891525048137
      ],
      [
        8,
        14,
        0.02424166367220477
      ],
      [
        8,
        15,
        0.024349048881851503
      ],
      [
        9,
        10,
        0.024395073381788108
      ],
      [
        9,
        11,
        0.024408284848179935
      ],
      [
        9,
        12,
        0.024396633368114422
      ],
      [
        9,
        13,
        0.02443323691227275
      ],
      [
        9,
        14,
        0.02426194961720685
      ],
      [
        9,
        15,
        0.024334129269032754
      ],
      [
        10,
        11,
        0.024677139644711122
      ],
      [
        10,
        12,
        0.024505769052940052
      ],
      [
        10,
        13,
        0.024502822371734585
      ],
      [
        10,
        14,
        0.024309020857858396
      ],
      [
        10,
        15,
        0.024542003865929172
      ],
      [
        11,
        12,
        0.024826834256937734
      ],
      [
        11,
        13,
        0.024837962654141458
      ],
      [
        11,
        14,
        0.02452119571602869
      ],
      [
        11,
        15,
        0.02488805686175238
      ],
      [
        12,
        13,
        0.024604681870167355
      ],
      [
        12,
        14,
        0.02442291354617988
      ],
      [
        12,
        15,
        0.024697786792306015
      ],
      [
        13,
        14,
        0.02435788749629668
      ],
      [
        13,
        15,
        0.024707227211934687
      ],
      [
        14,
        15,
        0.024722333284614453
      ]
    ],
    "offset": 0.6697092629375938
  },
  "market_data": {
    "covariance": {
      "annualized": true,
      "basis": "ticker",
      "matrix": [
        [
          0.05601221845147512,
          0.007906384217877255,
          0.03276101627901825,
          0.007990184839544279,
          0.02437104564900363,
          0.03130647158687126,
          0.03050592762149444,
          0.02708789276943781,
          0.03920115451133546,
          0.008612591643597279,
          0.03517083434838604,
          0.02117668787285101,
          0.01140356433096085,
          0.01093922893859076,
          0.02350705260007369,
          0.05309989998051468,
          0.05284962458313681,
          0.05611574888924693,
          0.05191883041189033,
          0.05539500420348303,
          0.03604124583779671,
          0.04995496837436415,
          0.05082098671862108,
          0.03439415571760561,
          0.04598624526801817,
          0.009846541493532441,
          0.00973814842295279,
          0.02720681266781347,
          0.02305329429816774,
          0.01969082699761569,
          0.0001867943493221829,
          0.005992006053617821,
          -0.005947300457531219,
          0.001696632981478057,
          0.01065065303737105,
          0.04696617688038069,
          0.02105244840721073,
          0.02103451461531883,
          0.02454014777786052,
          0.02901966319896379
        ],
        [
          0.007906384217877255,
          0.05688065655918412,
          0.01972140099068595,
          0.02170734772800753,
          0.02471303981902794,
          0.0187116557260933,
          0.02202965963179565,
          0.01665153636589725,
          0.01408410508386037,
          0.02703290627302732,
          0.01775619289394575,
          0.02397119237730158,
          0.02072599998215497,
          0.02057467644838805,
          0.02226151774872057,
          -0.002976275541664322,
          0.01016489539739113,
          0.01143775559847447,
          0.021821662630272,
          0.02019520572144413,
          0.01119411080851002,
          0.00894709332117058,
          0.01271524844608705,
          0.00358971163102163,
          0.01965284176647336,
          0.01403809859532139,
          0.01294327860537843,
          0.02513903608108121,
          0.01769468740914463,
          0.01222622342879849,
          0.0001593909098490275,
          0.003137947126972661,
          -0.003106158893525435,
          0.00290977230194554,
          0.01853235249397959,
          0.0523218867941689,
          0.01240289217600147,
          0.001587864318463464,
          0.01706701041027249,
          0.01339146554303869
        ],
        [
          0.03276101627901825,
          0.01972140099068595,
          0.1148039786300139,
          0.0249839566371551,
          0.03708093565462302,
          0.05168408697516733,
          0.07969578606460823,
          0.001241993604204666,
          0.01445769731897262,
          0.0667724488575342,
          0.099321209893285,
          0.07523387163689578,
          0.03101017797380442,
          0.06685919821155796,
          0.09468572029791969,
          0.0813467681965823,
          0.01295318761431985,
          0.03801753263831136,
          0.03855801443408365,
          0.04676700619208597,
          0.02097508716820532,
          0.04195690199721738,
          0.02257929501017263,
          0.02666260459548591,
          0.05563849159945437,
          0.001882104907818742,
          0.001780816451465664,
          0.02858745265564034,
          -0.004455862833534357,
          -0.002121221375982045,
          0.005284025026065915,
          0.02152165296806943,
          -0.01891372493274433,
          -0.008961472439591668,
          0.02217365846382422,
          0.07218184204983384,
          0.02766276194794431,
          0.01208681930231706,
          0.02890514035720127,
          0.04848209475707851
        ],
        [
          0.007990184839544279,
          0.02170734772800753,
          0.0249839566371551,
          0.08966739476614116,
          0.03432709702946506,
          0.02308955096845013,
          0.04500249097038597,
          0.009943884480121113,
          0.009891283047939455,
          0.04259388276993392,
          0.04886843151250718,
          0.04158300055719844,
          0.03916984672111842,
          0.04327115834705064,
          0.05742545976515648,
          0.02102093602336048,
          0.01541333629192558,
          0.0192227091507232,
          0.02420731745138185,
          0.02658897016537821,
          0.01629349406961091,
          0.02584961337129763,
          0.01401172976728743,
          0.01045103731155072,
          0.02232818482514936,
          0.005863133256081166,
          0.004034659220099536,
          0.01491270969371128,
          0.0001467329082880846,
          0.01128179889757745,
          0.006503514181554124,
          0.01463584837763812,
          -0.00382527311433619,
          -0.0002685324552923153,
          0.01247948546462016,
          0.0545818930028811,
          0.02647404398432487,
          0.00459612676672523,
          0.02669202870435369,
          0.03030852058643051
        ],
        [
          0.02437104564900363,
          0.02471303981902794,
          0.03708093565462302,
          0.03432709702946506,
          0.09428415576805002,
          0.05223946237062259,
          0.03638601730134387,
          0.02480427692552591,
          0.02829206989034245,
          0.03959190126865165,
          0.05626947103333965,
          0.04044830237133464,
          0.03959597916374203,
          0.05484200630521083,
          0.06409749403058201,
          0.02313987046482709,
          0.0250114487198523,
          0.03401472915993178,
          0.03329005259327494,
          0.04573480758839785,
          0.02326478716724893,
          0.02940223706575948,
          0.03021609148193304,
          0.0218410438661612,
          0.04490581500879112,
          0.01627894424787918,
          0.01796008873191986,
          0.04302908697633925,
          0.0293070492456873,
          0.01368865341987584,
          0.001745124051880918,
          0.008175543858296521,
          -0.0109207351818827,
          -0.006325665498067919,
          0.01752605672956889,
          0.07468176712949426,
          0.03089835282284425,
          0.01895089566662791,
          0.03917624582540087,
          0.03438464551779603
        ],
        [
          0.03130647158687126,
          0.0187116557260933,
          0.05168408697516733,
          0.02308955096845013,
          0.05223946237062259,
          0.1295143010717103,
          0.04882488230176679,
          0.01497493854152446,
          0.0201997010258822,
          0.04516802485645683,
          0.05489154349202915,
          0.04547243205192244,
          0.01182538182301092,
          0.05304114454606193,
          0.05443551639760438,
          0.04496507104249722,
          0.01107920765335609,
          0.02631605655679243,
          0.01495061158138451,
          0.03106349564042742,
          0.01898016194193941,
          0.02907596547493398,
          0.02600318208704476,
          0.03656573846705009,
          0.04501042684790311,
          0.01869425828053165,
          0.02867082067284136,
          0.03912531983096325,
          0.03051911614090234,
          0.0125662688088701,
          0.001883048788477336,
          0.01206060686559287,
          -0.007257902395266277,
          -0.007678447578122359,
          0.01499564855466,
          0.08078445113529868,
          0.03506373738175995,
          0.02150987110482942,
          0.04015228438601411,
          0.04375508943395876
        ],
        [
          0.03050592762149444,
          0.02202965963179565,
          0.07969578606460823,
          0.04500249097038597,
          0.03638601730134387,
          0.04882488230176679,
          0.1806569658202924,
          0.004557704791409768,
          0.01468830148738162,
          0.08010422674469037,
          0.09370306440434088,
          0.09437412369374042,
          0.04260403862512143,
          0.07535581926413343,
          0.110767141551133,
          0.127236677273427,
          0.02687919083778982,
          0.06284399912826838,
          0.06050766748385939,
          0.07300712327678265,
          0.03710957507610767,
          0.06255435771814294,
          0.03587878721936405,
          0.03414814847654768,
          0.07427302122686945,
          0.005719948695678691,
          0.001040835106074422,
          0.02728150726764799,
          -0.007375881088118087,
          0.005333838588801857,
          0.008170081334527322,
          0.03358908959719357,
          -0.01334816323018048,
          -0.006548812600984307,
          0.02903271039510854,
          0.09244319452498344,
          0.02814249078956028,
          0.03484301933168717,
          0.03473386431570822,
          0.06199003547987403
        ],
        [
          0.02708789276943781,
          0.01665153636589725,
          0.001241993604204666,
          0.009943884480121113,
          0.02480427692552591,
          0.01497493854152446,
          0.004557704791409768,
          0.09886765140106077,
          0.07628269433733073,
          -0.002752641894717859,
          0.006226067725502628,
          -0.002018955664574076,
          0.03741625002114558,
          0.01795996051596158,
          -0.008105888049368425,
          0.02045770571048761,
          0.0843950865007156,
          0.0502192490564714,
          0.04624496477683553,
          0.04156025284328509,
          0.04519461697678242,
          0.04325099110864103,
          0.05510859612984221,
          0.04517874103848132,
          0.02959356255901065,
          0.02461039706303139,
          0.02707237594577502,
          0.05980137510857508,
          0.06683770152863319,
          0.04581941515018972,
          0.009756853285301174,
          0.004864210025593407,
          0.000961298733540948,
          0.01001414122222784,
          0.002992208106984554,
          0.05515612263206462,
          0.02071833664184224,
          0.01891952473025298,
          0.03443391534031886,
          0.01664052513157079
        ],
        [
          0.03920115451133546,
          0.01408410508386037,
          0.01445769731897262,
          0.009891283047939455,
          0.02829206989034245,
          0.0201997010258822,
          0.01468830148738162,
          0.07628269433733073,
          0.1204797301407446,
          0.0005792392023690057,
          0.009271787626992021,
          0.004688921156978194,
          0.03339978392999893,
          0.01227152997801575,
          0.00890087154295637,
          0.047105065353531,
          0.1098846562102709,
          0.0873248543259002,
          0.0722277899294489,
          0.09419654060432107,
          0.06314194661168501,
          0.06623251159302433,
          0.08653924984623475,
          0.06605293683112749,
          0.06220531857296883,
          0.02040521136420761,
          0.02091823384355308,
          0.05787337972135874,
          0.04148304569784502,
          0.04533122972102489,
          0.005084456633940026,
          0.0001708274402655289,
          -0.006122468077318948,
          0.001494412704246157,
          0.003401966715303593,
          0.07488709015328097,
          0.02716869661751703,
          0.03220993622472965,
          0.04001326352616551,
          0.02925126312042527
        ],
        [
          0.008612591643597279,
          0.02703290627302732,
          0.0667724488575342,
          0.04259388276993392,
          0.03959190126865165,
          0.04516802485645683,
          0.08010422674469037,
          -0.002752641894717859,
          0.0005792392023690057,
          0.1504609720769132,
          0.09226369833352223,
          0.09148284794314818,
          0.05534249424523485,
          0.1079151540302058,
          0.1327861213614202,
          0.03808007937699188,
          -0.00385858634066295,
          0.03424927500012557,
          0.0256114836222523,
          0.04355080029646265,
          0.01449575794065147,
          0.03030637617230156,
          -0.001026714118423336,
          0.01372033389920922,
          0.03612948544279353,
          0.009453712825604884,
          0.007322488306504915,
          0.03412250113717032,
          0.003430720892111644,
          0.005696065510219233,
          0.01636638583083698,
          0.02833782266146035,
          -0.0108243792874568,
          -0.009004498587098073,
          0.02995030958869207,
          0.06451267285464926,
          0.03942044249260007,
          0.01690034639503324,
          0.04167287816001318,
          0.05725217662868929
        ],
        [
          0.03517083434838604,
          0.01775619289394575,
          0.099321209893285,
          0.04886843151250718,
          0.05626947103333965,
          0.05489154349202915,
          0.09370306440434088,
          0.006226067725502628,
          0.009271787626992021,
          0.09226369833352223,
          0.362069031118813,
          0.1150193861811959,
          0.07776476474707421,
          0.1443383912746823,
          0.1543811575181995,
          0.0850985186578663,
          0.01313519065603778,
          0.05512836766594314,
          0.05066437549669636,
          0.04451271982836347,
          0.02325357652142241,
          0.03938535605803559,
          0.02322942031819436,
          0.02080802545986012,
          0.06806181796102212,
          0.007749437908178858,
          -0.001244466368873086,
          0.05913758786740395,
          0.0009083092588763642,
          0.008046529569230215,
          0.01746492816251709,
          0.03085955974237431,
          -0.01855772817887716,
          0.001076002916241132,
          0.04911166104379331,
          0.07159502308833077,
          0.0537651351136353,
          0.03030777650451835,
          0.04690589748937688,
          0.06796250668203518
        ],
        [
          0.02117668787285101,
          0.02397119237730158,
          0.07523387163689578,
          0.04158300055719844,
          0.04044830237133464,
          0.04547243205192244,
          0.09437412369374042,
          -0.002018955664574076,
          0.004688921156978194,
          0.09148284794314818,
          0.1150193861811959,
          0.1232785020035762,
          0.04587142443219554,
          0.07695083407929071,
          0.1268992000495197,
          0.0780206886061671,
          0.006839874879511609,
          0.03952261761423246,
          0.03792211968531684,
          0.05887724607260067,
          0.01453920569542958,
          0.02896223605753068,
          0.01123314851333005,
          0.0131937849309509,
          0.04939542565739314,
          0.007368080356816969,
          0.004505887790464784,
          0.02669987650073385,
          0.001945110545881967,
          0.005688796064509229,
          0.0156778994668131,
          0.02942572688387666,
          -0.008013466303937181,
          -0.003504154652388582,
          0.02848691574248027,
          0.07403836089186241,
          0.03333651178171073,
          0.01590475749409362,
          0.0297576777145695,
          0.05246956987454805
        ],
        [
          0.01140356433096085,
          0.02072599998215497,
          0.03101017797380442,
          0.03916984672111842,
          0.03959597916374203,
          0.01182538182301092,
          0.04260403862512143,
          0.03741625002114558,
          0.03339978392999893,
          0.05534249424523485,
          0.07776476474707421,
          0.04587142443219554,
          0.1306008656209391,
          0.08424844145857975,
          0.06386400941304289,
          0.03008871856795737,
          0.04129157300765671,
          0.02461252357336271,
          0.03156477858121118,
          0.03704751435907654,
          0.03306671566140026,
          0.03229688203449623,
          0.02662151392042233,
          0.02290077374478832,
          0.02837383354330924,
          0.01738890211127133,
          0.01247961816383159,
          0.04448601639004156,
          0.03883817213474033,
          0.02564173849888569,
          0.007241928614674555,
          0.01744798982912175,
          0.002842127434296491,
          0.0123317835038457,
          0.02001177290745692,
          0.05809525546497067,
          0.02449181080167335,
          0.02167114479323277,
          0.04133077269130262,
          0.04063009806259004
        ],
        [
          0.01093922893859076,
          0.02057467644838805,
          0.06685919821155796,
          0.04327115834705064,
          0.05484200630521083,
          0.05304114454606193,
          0.07535581926413343,
          0.01795996051596158,
          0.01227152997801575,
          0.1079151540302058,
          0.1443383912746823,
          0.07695083407929071,
          0.08424844145857975,
          0.4656194569566944,
          0.1644747304702268,
          0.02927263086963663,
          -0.005068152182459907,
          0.02987408391413711,
          0.03780845202040283,
          0.06012344534810486,
          0.0415239329633667,
          0.06958638796406616,
          0.01826465033716791,
          0.02876260838811307,
          0.05198292062620694,
          0.01450751246487476,
          0.009451245915543468,
          0.04305015808111271,
          0.0198184330830783,
          -0.002100328033257989,
          0.01771744707779684,
          0.02940500456781639,
          -0.01962266179899331,
          -0.009737126910651662,
          0.03513460375759432,
          0.03907677445400887,
          0.03644782566869627,
          0.0003735015588894674,
          0.04413456169612263,
          0.0562995016173175
        ],
        [
          0.02350705260007369,
          0.02226151774872057,
          0.09468572029791969,
          0.05742545976515648,
          0.06409749403058201,
          0.05443551639760438,
          0.110767141551133,
          -0.008105888049368425,
          0.00890087154295637,
          0.1327861213614202,
          0.1543811575181995,
          0.1268992000495197,
          0.06386400941304289,
          0.1644747304702268,
          0.3501058004599857,
          0.08277051642399542,
          -0.001589696569850865,
          0.05769318565919766,
          0.06002146163171191,
          0.07502081816054473,
          0.02080558134080416,
          0.05933603090170908,
          0.02286814030334015,
          0.02269400819233502,
          0.06580181160672027,
          0.009118115864112928,
          0.003899201850110712,
          0.02708973450955807,
          -0.003413961000806931,
          0.005846336928687167,
          0.02094674414361864,
          0.03108942895292692,
          -0.02312912085248881,
          -0.01848669214329455,
          0.03568663227581514,
          0.07458337661603201,
          0.05480693877836004,
          0.01500821166298665,
          0.039034622884687,
          0.07917979674676501
        ],
        [
          0.05309989998051468,
          -0.002976275541664322,
          0.0813467681965823,
          0.02102093602336048,
          0.02313987046482709,
          0.04496507104249722,
          0.127236677273427,
          0.02045770571048761,
          0.047105065353531,
          0.03808007937699188,
          0.0850985186578663,
          0.0780206886061671,
          0.03008871856795737,
          0.02927263086963663,
          0.08277051642399542,
          0.3857472082610473,
          0.0712733983313814,
          0.108744978785258,
          0.1007824620819103,
          0.1114530946818912,
          0.06400531506465054,
          0.09398796941509754,
          0.07954934060774281,
          0.06536523820749357,
          0.1154456287570097,
          -0.01294076086766383,
          -0.005630196256451513,
          0.02459580445279915,
          0.0204582306670083,
          0.009859083473140877,
          0.01332493986013315,
          0.05345548605449155,
          -0.008350203246147572,
          0.00211036654189982,
          0.02287651392427394,
          0.1008644204175122,
          0.03621926922457007,
          0.03762782931359011,
          0.03113435294780137,
          0.04017724567764074
        ],
        [
          0.05284962458313681,
          0.01016489539739113,
          0.01295318761431985,
          0.01541333629192558,
          0.0250114487198523,
          0.01107920765335609,
          0.02687919083778982,
          0.0843950865007156,
          0.1098846562102709,
          -0.00385858634066295,
          0.01313519065603778,
          0.006839874879511609,
          0.04129157300765671,
          -0.005068152182459907,
          -0.001589696569850865,
          0.0712733983313814,
          0.1829391504780994,
          0.1192232271856895,
          0.1142618759423793,
          0.1092972689632395,
          0.08299218535610589,
          0.09731947915768233,
          0.1203373520640852,
          0.07917545358086711,
          0.08590531432916002,
          0.02135979883384592,
          0.02330372170097929,
          0.06550137540605365,
          0.05531475516668388,
          0.05341395700954873,
          0.0005176462527245028,
          0.002013175444611674,
          -0.003836964712483501,
          0.005758343589987703,
          0.005725253372495837,
          0.09042380088122222,
          0.03761588697980818,
          0.04833025177627035,
          0.04588040977907952,
          0.04108585913758377
        ],
        [
          0.05611574888924693,
          0.01143775559847447,
          0.03801753263831136,
          0.0192227091507232,
          0.03401472915993178,
          0.02631605655679243,
          0.06284399912826838,
          0.0502192490564714,
          0.0873248543259002,
          0.03424927500012557,
          0.05512836766594314,
          0.03952261761423246,
          0.02461252357336271,
          0.02987408391413711,
          0.05769318565919766,
          0.108744978785258,
          0.1192232271856895,
          0.2719067769526857,
          0.1650840233022047,
          0.1855799180907946,
          0.09203894846991396,
          0.1359308308577281,
          0.1366207208208155,
          0.07921594017512289,
          0.1482974672690257,
          0.02134813373032,
          0.01998472511822297,
          0.06549652365151604,
          0.03741867156793968,
          0.04319270640938115,
          0.01077969360873201,
          0.01310675362296844,
          -0.01535422343189283,
          -0.007404584592961545,
          0.0207234047332375,
          0.1196756063909578,
          0.05373652278707492,
          0.04843857837021961,
          0.05483305509214139,
          0.06099220555282082
        ],
        [
          0.05191883041189033,
          0.021821662630272,
          0.03855801443408365,
          0.02420731745138185,
          0.03329005259327494,
          0.01495061158138451,
          0.06050766748385939,
          0.04624496477683553,
          0.0722277899294489,
          0.0256114836222523,
          0.05066437549669636,
          0.03792211968531684,
          0.03156477858121118,
          0.03780845202040283,
          0.06002146163171191,
          0.1007824620819103,
          0.1142618759423793,
          0.1650840233022047,
          0.2993313174683707,
          0.1726959244117352,
          0.09642503532282701,
          0.1334118331323857,
          0.1369747291645755,
          0.06312911515169413,
          0.1418697382420543,
          0.02196548733698373,
          0.01781210461219131,
          0.05249327511723113,
          0.0511437174088471,
          0.04456915241424396,
          0.01093566715016279,
          0.01810739862106685,
          -0.009604755229312843,
          -0.0004358239867439438,
          0.02097567552140124,
          0.109172352306342,
          0.05305000936100415,
          0.07539210493671948,
          0.03209549251103057,
          0.06140002836689943
        ],
        [
          0.05539500420348303,
          0.02019520572144413,
          0.04676700619208597,
          0.02658897016537821,
          0.04573480758839785,
          0.03106349564042742,
          0.07300712327678265,
          0.04156025284328509,
          0.09419654060432107,
          0.04355080029646265,
          0.04451271982836347,
          0.05887724607260067,
          0.03704751435907654,
          0.06012344534810486,
          0.07502081816054473,
          0.1114530946818912,
          0.1092972689632395,
          0.1855799180907946,
          0.1726959244117352,
          0.4653372492156649,
          0.0815480671797654,
          0.1159583959950526,
          0.1224063822071488,
          0.07854913794398476,
          0.1589845776442111,
          0.01799523670128701,
          0.01765494065246467,
          0.0463274225720383,
          0.03816198113315584,
          0.03875050462227189,
          0.01104971732194269,
          0.02116430002921236,
          -0.01404525372102137,
          -0.007427179258669665,
          0.02246327593808739,
          0.1284652417324167,
          0.04586267691508208,
          0.05415683461957311,
          0.067118662620197,
          0.1052301600868353
        ],
        [
          0.03604124583779671,
          0.01119411080851002,
          0.02097508716820532,
          0.01629349406961091,
          0.02326478716724893,
          0.01898016194193941,
          0.03710957507610767,
          0.04519461697678242,
          0.06314194661168501,
          0.01449575794065147,
          0.02325357652142241,
          0.01453920569542958,
          0.03306671566140026,
          0.0415239329633667,
          0.02080558134080416,
          0.06400531506465054,
          0.08299218535610589,
          0.09203894846991396,
          0.09642503532282701,
          0.0815480671797654,
          0.1194536118102019,
          0.1018125558155362,
          0.09604802750674102,
          0.07901481636113887,
          0.08492035338884561,
          0.01653790766238467,
          0.01554092622075497,
          0.04756071494631957,
          0.03505316578235224,
          0.0288542707770821,
          0.01139013704017972,
          0.01507390608965981,
          0.004169516104068525,
          0.01392308922617348,
          0.01569121960449536,
          0.06794404173438993,
          0.03033865808332143,
          0.04298866436912632,
          0.03051876412844875,
          0.03412279177665234
        ],
        [
          0.04995496837436415,
          0.00894709332117058,
          0.04195690199721738,
          0.02584961337129763,
          0.02940223706575948,
          0.02907596547493398,
          0.06255435771814294,
          0.04325099110864103,
          0.06623251159302433,
          0.03030637617230156,
          0.03938535605803559,
          0.02896223605753068,
          0.03229688203449623,
          0.06958638796406616,
          0.05933603090170908,
          0.09398796941509754,
          0.09731947915768233,
          0.1359308308577281,
          0.1334118331323857,
          0.1159583959950526,
          0.1018125558155362,
          0.1778468064347277,
          0.139255769740079,
          0.09417628091998752,
          0.1359800507012327,
          0.01126264119406279,
          0.01045576024101384,
          0.03736148361969042,
          0.03736392283138758,
          0.02974936676572696,
          -0.000215529525327707,
          0.01260928232800865,
          -0.01371580837633263,
          0.0007258588900315232,
          0.02345109813792865,
          0.09891350410866467,
          0.03759228659622076,
          0.05080829333368424,
          0.03721876419785056,
          0.04305716879453185
        ],
        [
          0.05082098671862108,
          0.01271524844608705,
          0.02257929501017263,
          0.01401172976728743,
          0.03021609148193304,
          0.02600318208704476,
          0.03587878721936405,
          0.05510859612984221,
          0.08653924984623475,
          -0.001026714118423336,
          0.02322942031819436,
          0.01123314851333005,
          0.02662151392042233,
          0.01826465033716791,
          0.02286814030334015,
          0.07954934060774281,
          0.1203373520640852,
          0.1366207208208155,
          0.1369747291645755,
          0.1224063822071488,
          0.09604802750674102,
          0.139255769740079,
          0.2030299705591965,
          0.08817980818818928,
          0.130969545638729,
          0.01658017630959924,
          0.01794410632916613,
          0.04384827093961463,
          0.04934875207368828,
          0.04131510550029092,
          -0.0008414723605043194,
          0.007007772584194273,
          -0.008923429374584926,
          0.005216349331731871,
          0.0115091415521027,
          0.1002710568926623,
          0.03473007582536182,
          0.0497952653358002,
          0.03555683498020182,
          0.04135133266432348
        ],
        [
          0.03439415571760561,
          0.00358971163102163,
          0.02666260459548591,
          0.01045103731155072,
          0.0218410438661612,
          0.03656573846705009,
          0.03414814847654768,
          0.04517874103848132,
          0.06605293683112749,
          0.01372033389920922,
          0.02080802545986012,
          0.0131937849309509,
          0.02290077374478832,
          0.02876260838811307,
          0.02269400819233502,
          0.06536523820749357,
          0.07917545358086711,
          0.07921594017512289,
          0.06312911515169413,
          0.07854913794398476,
          0.07901481636113887,
          0.09417628091998752,
          0.08817980818818928,
          0.1542637079648745,
          0.08661788379656837,
          0.022800047284838,
          0.01887757920760072,
          0.03793140003369515,
          0.03984734560068701,
          0.02281879135237345,
          0.00998404995395675,
          0.01440581132969364,
          -0.007344503743100769,
          0.001292059943747188,
          0.01901597784859399,
          0.07322597617606179,
          0.02096129573864663,
          0.02363872244113216,
          0.02251108011299078,
          0.03844127097637458
        ],
        [
          0.04598624526801817,
          0.01965284176647336,
          0.05563849159945437,
          0.02232818482514936,
          0.04490581500879112,
          0.04501042684790311,
          0.07427302122686945,
          0.02959356255901065,
          0.06220531857296883,
          0.03612948544279353,
          0.06806181796102212,
          0.04939542565739314,
          0.02837383354330924,
          0.05198292062620694,
          0.06580181160672027,
          0.1154456287570097,
          0.08590531432916002,
          0.1482974672690257,
          0.1418697382420543,
          0.1589845776442111,
          0.08492035338884561,
          0.1359800507012327,
          0.130969545638729,
          0.08661788379656837,
          0.2657864600759731,
          0.01090189332798759,
          0.01184064651937265,
          0.04621942027781083,
          0.03821263399084528,
          0.02803974786788449,
          0.01001803340780285,
          0.02373472875033504,
          -0.01711614113866569,
          -0.004973902871413095,
          0.02657408364260363,
          0.119459012726771,
          0.05011661349956315,
          0.06465356536122989,
          0.05103227925257627,
          0.05436571704437344
        ],
        [
          0.009846541493532441,
          0.01403809859532139,
          0.001882104907818742,
          0.005863133256081166,
          0.01627894424787918,
          0.01869425828053165,
          0.005719948695678691,
          0.02461039706303139,
          0.02040521136420761,
          0.009453712825604884,
          0.007749437908178858,
          0.007368080356816969,
          0.01738890211127133,
          0.01450751246487476,
          0.009118115864112928,
          -0.01294076086766383,
          0.02135979883384592,
          0.02134813373032,
          0.02196548733698373,
          0.01799523670128701,
          0.01653790766238467,
          0.01126264119406279,
          0.01658017630959924,
          0.022800047284838,
          0.01090189332798759,
          0.04840923567225749,
          0.04127546347863749,
          0.03139296115562033,
          0.03232771826669073,
          0.02796867576447711,
          0.009112480210069959,
          0.004520268123458531,
          0.003916464571889463,
          0.005723345237717359,
          0.01181719679107648,
          0.03613793792970605,
          0.01582278907246157,
          0.02117831425145257,
          0.01537805033366118,
          0.01714002081614542
        ],
        [
          0.00973814842295279,
          0.01294327860537843,
          0.001780816451465664,
          0.004034659220099536,
          0.01796008873191986,
          0.02867082067284136,
          0.001040835106074422,
          0.02707237594577502,
          0.02091823384355308,
          0.007322488306504915,
          -0.001244466368873086,
          0.004505887790464784,
          0.01247961816383159,
          0.009451245915543468,
          0.003899201850110712,
          -0.005630196256451513,
          0.02330372170097929,
          0.01998472511822297,
          0.01781210461219131,
          0.01765494065246467,
          0.01554092622075497,
          0.01045576024101384,
          0.01794410632916613,
          0.01887757920760072,
          0.01184064651937265,
          0.04127546347863749,
          0.04743673467230081,
          0.02811420281371454,
          0.03592994618774897,
          0.0286228694263293,
          0.006912188641772874,
          0.002623798359948167,
          0.002317455011710148,
          0.003591750853899664,
          0.01080037291691458,
          0.03912056197589384,
          0.01951294922317513,
          0.01732341574751737,
          0.01497322360938048,
          0.01311295923493419
        ],
        [
          0.02720681266781347,
          0.02513903608108121,
          0.02858745265564034,
          0.01491270969371128,
          0.04302908697633925,
          0.03912531983096325,
          0.02728150726764799,
          0.05980137510857508,
          0.05787337972135874,
          0.03412250113717032,
          0.05913758786740395,
          0.02669987650073385,
          0.04448601639004156,
          0.04305015808111271,
          0.02708973450955807,
          0.02459580445279915,
          0.06550137540605365,
          0.06549652365151604,
          0.05249327511723113,
          0.0463274225720383,
          0.04756071494631957,
          0.03736148361969042,
          0.04384827093961463,
          0.03793140003369515,
          0.04621942027781083,
          0.03139296115562033,
          0.02811420281371454,
          0.1485729689309009,
          0.07787016401440323,
          0.0577433283874605,
          0.01112001444083121,
          0.01006902802692976,
          0.009774507743818163,
          0.01589403888971019,
          0.01533046679564956,
          0.09501803514784474,
          0.03744367976453,
          0.05156133081147563,
          0.04215110938115214,
          0.03914758075447743
        ],
        [
          0.02305329429816774,
          0.01769468740914463,
          -0.004455862833534357,
          0.0001467329082880846,
          0.0293070492456873,
          0.03051911614090234,
          -0.007375881088118087,
          0.06683770152863319,
          0.04148304569784502,
          0.003430720892111644,
          0.0009083092588763642,
          0.001945110545881967,
          0.03883817213474033,
          0.0198184330830783,
          -0.003413961000806931,
          0.0204582306670083,
          0.05531475516668388,
          0.03741867156793968,
          0.0511437174088471,
          0.03816198113315584,
          0.03505316578235224,
          0.03736392283138758,
          0.04934875207368828,
          0.03984734560068701,
          0.03821263399084528,
          0.03232771826669073,
          0.03592994618774897,
          0.07787016401440323,
          0.3236880437973025,
          0.06861222889684045,
          0.01569877547795305,
          0.02097615475336469,
          0.01085211820425286,
          0.02358076767480784,
          0.01389406858218581,
          0.05930303738012147,
          0.02781336403733484,
          0.02312795606070672,
          0.02412067405422366,
          0.03190516809372871
        ],
        [
          0.01969082699761569,
          0.01222622342879849,
          -0.002121221375982045,
          0.01128179889757745,
          0.01368865341987584,
          0.0125662688088701,
          0.005333838588801857,
          0.04581941515018972,
          0.04533122972102489,
          0.005696065510219233,
          0.008046529569230215,
          0.005688796064509229,
          0.02564173849888569,
          -0.002100328033257989,
          0.005846336928687167,
          0.009859083473140877,
          0.05341395700954873,
          0.04319270640938115,
          0.04456915241424396,
          0.03875050462227189,
          0.0288542707770821,
          0.02974936676572696,
          0.04131510550029092,
          0.02281879135237345,
          0.02803974786788449,
          0.02796867576447711,
          0.0286228694263293,
          0.0577433283874605,
          0.06861222889684045,
          0.08046650109361096,
          0.007816446757015027,
          0.005394756091005677,
          0.00825564455545131,
          0.01270169387771134,
          0.01065846043456991,
          0.04690947959168678,
          0.01650039289085315,
          0.02859356567509677,
          0.01983015209217897,
          0.03271794137103241
        ],
        [
          0.0001867943493221829,
          0.0001593909098490275,
          0.005284025026065915,
          0.006503514181554124,
          0.001745124051880918,
          0.001883048788477336,
          0.008170081334527322,
          0.009756853285301174,
          0.005084456633940026,
          0.01636638583083698,
          0.01746492816251709,
          0.0156778994668131,
          0.007241928614674555,
          0.01771744707779684,
          0.02094674414361864,
          0.01332493986013315,
          0.0005176462527245028,
          0.01077969360873201,
          0.01093566715016279,
          0.01104971732194269,
          0.01139013704017972,
          -0.000215529525327707,
          -0.0008414723605043194,
          0.00998404995395675,
          0.01001803340780285,
          0.009112480210069959,
          0.006912188641772874,
          0.01112001444083121,
          0.01569877547795305,
          0.007816446757015027,
          0.0672214774691121,
          0.03329200697492956,
          0.01933436729333865,
          0.02093075151693431,
          -0.005133129938698687,
          0.005308047077738647,
          0.008776601374137851,
          -0.01323744437827777,
          0.007348514257945238,
          0.003436390204331655
        ],
        [
          0.005992006053617821,
          0.003137947126972661,
          0.02152165296806943,
          0.01463584837763812,
          0.008175543858296521,
          0.01206060686559287,
          0.03358908959719357,
          0.004864210025593407,
          0.0001708274402655289,
          0.02833782266146035,
          0.03085955974237431,
          0.02942572688387666,
          0.01744798982912175,
          0.02940500456781639,
          0.03108942895292692,
          0.05345548605449155,
          0.002013175444611674,
          0.01310675362296844,
          0.01810739862106685,
          0.02116430002921236,
          0.01507390608965981,
          0.01260928232800865,
          0.007007772584194273,
          0.01440581132969364,
          0.02373472875033504,
          0.004520268123458531,
          0.002623798359948167,
          0.01006902802692976,
          0.02097615475336469,
          0.005394756091005677,
          0.03329200697492956,
          0.047034083840639,
          0.01474730502121785,
          0.02054406820202425,
          0.007494924974554017,
          0.02052233079513702,
          0.01235621684560329,
          -0.003894607486216599,
          0.01255732487123163,
          0.013896793623825
        ],
        [
          -0.005947300457531219,
          -0.003106158893525435,
          -0.01891372493274433,
          -0.00382527311433619,
          -0.0109207351818827,
          -0.007257902395266277,
          -0.01334816323018048,
          0.000961298733540948,
          -0.006122468077318948,
          -0.0108243792874568,
          -0.01855772817887716,
          -0.008013466303937181,
          0.002842127434296491,
          -0.01962266179899331,
          -0.02312912085248881,
          -0.008350203246147572,
          -0.003836964712483501,
          -0.01535422343189283,
          -0.009604755229312843,
          -0.01404525372102137,
          0.004169516104068525,
          -0.01371580837633263,
          -0.008923429374584926,
          -0.007344503743100769,
          -0.01711614113866569,
          0.003916464571889463,
          0.002317455011710148,
          0.009774507743818163,
          0.01085211820425286,
          0.00825564455545131,
          0.01933436729333865,
          0.01474730502121785,
          0.0547342003624534,
          0.05038511584813283,
          -0.007831485847060884,
          -0.01055645636876581,
          -0.004284528561019354,
          0.007769610351891968,
          0.006748110555569278,
          -0.006775127356360478
        ],
        [
          0.001696632981478057,
          0.00290977230194554,
          -0.008961472439591668,
          -0.0002685324552923153,
          -0.006325665498067919,
          -0.007678447578122359,
          -0.006548812600984307,
          0.01001414122222784,
          0.001494412704246157,
          -0.009004498587098073,
          0.001076002916241132,
          -0.003504154652388582,
          0.0123317835038457,
          -0.009737126910651662,
          -0.01848669214329455,
          0.00211036654189982,
          0.005758343589987703,
          -0.007404584592961545,
          -0.0004358239867439438,
          -0.007427179258669665,
          0.01392308922617348,
          0.0007258588900315232,
          0.005216349331731871,
          0.001292059943747188,
          -0.004973902871413095,
          0.005723345237717359,
          0.003591750853899664,
          0.01589403888971019,
          0.02358076767480784,
          0.01270169387771134,
          0.02093075151693431,
          0.02054406820202425,
          0.05038511584813283,
          0.06892922737407592,
          -0.002414223481197018,
          0.0002364968839809979,
          -0.003235377617913185,
          0.01030079707509484,
          0.007220823353114081,
          -0.01191475581137209
        ],
        [
          0.01065065303737105,
          0.01853235249397959,
          0.02217365846382422,
          0.01247948546462016,
          0.01752605672956889,
          0.01499564855466,
          0.02903271039510854,
          0.002992208106984554,
          0.003401966715303593,
          0.02995030958869207,
          0.04911166104379331,
          0.02848691574248027,
          0.02001177290745692,
          0.03513460375759432,
          0.03568663227581514,
          0.02287651392427394,
          0.005725253372495837,
          0.0207234047332375,
          0.02097567552140124,
          0.02246327593808739,
          0.01569121960449536,
          0.02345109813792865,
          0.0115091415521027,
          0.01901597784859399,
          0.02657408364260363,
          0.01181719679107648,
          0.01080037291691458,
          0.01533046679564956,
          0.01389406858218581,
          0.01065846043456991,
          -0.005133129938698687,
          0.007494924974554017,
          -0.007831485847060884,
          -0.002414223481197018,
          0.06541746929839297,
          0.04288633903545648,
          0.01401595450428797,
          0.02128892281212864,
          0.01467114299774847,
          0.02103795156055378
        ],
        [
          0.04696617688038069,
          0.0523218867941689,
          0.07218184204983384,
          0.0545818930028811,
          0.07468176712949426,
          0.08078445113529868,
          0.09244319452498344,
          0.05515612263206462,
          0.07488709015328097,
          0.06451267285464926,
          0.07159502308833077,
          0.07403836089186241,
          0.05809525546497067,
          0.03907677445400887,
          0.07458337661603201,
          0.1008644204175122,
          0.09042380088122222,
          0.1196756063909578,
          0.109172352306342,
          0.1284652417324167,
          0.06794404173438993,
          0.09891350410866467,
          0.1002710568926623,
          0.07322597617606179,
          0.119459012726771,
          0.03613793792970605,
          0.03912056197589384,
          0.09501803514784474,
          0.05930303738012147,
          0.04690947959168678,
          0.005308047077738647,
          0.02052233079513702,
          -0.01055645636876581,
          0.0002364968839809979,
          0.04288633903545648,
          0.3015325438413474,
          0.06559593632129716,
          0.07521280223536708,
          0.04922379293239248,
          0.07660809437814103
        ],
        [
          0.02105244840721073,
          0.01240289217600147,
          0.02766276194794431,
          0.02647404398432487,
          0.03089835282284425,
          0.03506373738175995,
          0.02814249078956028,
          0.02071833664184224,
          0.02716869661751703,
          0.03942044249260007,
          0.0537651351136353,
          0.03333651178171073,
          0.02449181080167335,
          0.03644782566869627,
          0.05480693877836004,
          0.03621926922457007,
          0.03761588697980818,
          0.05373652278707492,
          0.05305000936100415,
          0.04586267691508208,
          0.03033865808332143,
          0.03759228659622076,
          0.03473007582536182,
          0.02096129573864663,
          0.05011661349956315,
          0.01582278907246157,
          0.01951294922317513,
          0.03744367976453,
          0.02781336403733484,
          0.01650039289085315,
          0.008776601374137851,
          0.01235621684560329,
          -0.004284528561019354,
          -0.003235377617913185,
          0.01401595450428797,
          0.06559593632129716,
          0.1052242020308526,
          0.03642739518366803,
          0.03184042979741649,
          0.04471887782460724
        ],
        [
          0.02103451461531883,
          0.001587864318463464,
          0.01208681930231706,
          0.00459612676672523,
          0.01895089566662791,
          0.02150987110482942,
          0.03484301933168717,
          0.01891952473025298,
          0.03220993622472965,
          0.01690034639503324,
          0.03030777650451835,
          0.01590475749409362,
          0.02167114479323277,
          0.0003735015588894674,
          0.01500821166298665,
          0.03762782931359011,
          0.04833025177627035,
          0.04843857837021961,
          0.07539210493671948,
          0.05415683461957311,
          0.04298866436912632,
          0.05080829333368424,
          0.0497952653358002,
          0.02363872244113216,
          0.06465356536122989,
          0.02117831425145257,
          0.01732341574751737,
          0.05156133081147563,
          0.02312795606070672,
          0.02859356567509677,
          -0.01323744437827777,
          -0.003894607486216599,
          0.007769610351891968,
          0.01030079707509484,
          0.02128892281212864,
          0.07521280223536708,
          0.03642739518366803,
          0.1928890053816032,
          0.02918159807360332,
          0.05402529098434942
        ],
        [
          0.02454014777786052,
          0.01706701041027249,
          0.02890514035720127,
          0.02669202870435369,
          0.03917624582540087,
          0.04015228438601411,
          0.03473386431570822,
          0.03443391534031886,
          0.04001326352616551,
          0.04167287816001318,
          0.04690589748937688,
          0.0297576777145695,
          0.04133077269130262,
          0.04413456169612263,
          0.039034622884687,
          0.03113435294780137,
          0.04588040977907952,
          0.05483305509214139,
          0.03209549251103057,
          0.067118662620197,
          0.03051876412844875,
          0.03721876419785056,
          0.03555683498020182,
          0.02251108011299078,
          0.05103227925257627,
          0.01537805033366118,
          0.01497322360938048,
          0.04215110938115214,
          0.02412067405422366,
          0.01983015209217897,
          0.007348514257945238,
          0.01255732487123163,
          0.006748110555569278,
          0.007220823353114081,
          0.01467114299774847,
          0.04922379293239248,
          0.03184042979741649,
          0.02918159807360332,
          0.1378882816065886,
          0.08108417876705044
        ],
        [
          0.02901966319896379,
          0.01339146554303869,
          0.04848209475707851,
          0.03030852058643051,
          0.03438464551779603,
          0.04375508943395876,
          0.06199003547987403,
          0.01664052513157079,
          0.02925126312042527,
          0.05725217662868929,
          0.06796250668203518,
          0.05246956987454805,
          0.04063009806259004,
          0.0562995016173175,
          0.07917979674676501,
          0.04017724567764074,
          0.04108585913758377,
          0.06099220555282082,
          0.06140002836689943,
          0.1052301600868353,
          0.03412279177665234,
          0.04305716879453185,
          0.04135133266432348,
          0.03844127097637458,
          0.05436571704437344,
          0.01714002081614542,
          0.01311295923493419,
          0.03914758075447743,
          0.03190516809372871,
          0.03271794137103241,
          0.003436390204331655,
          0.013896793623825,
          -0.006775127356360478,
          -0.01191475581137209,
          0.02103795156055378,
          0.07660809437814103,
          0.04471887782460724,
          0.05402529098434942,
          0.08108417876705044,
          0.2347698742491694
        ]
      ],
      "tickers": [
        "MSFT",
        "AAPL",
        "NVDA",
        "GOOGL",
        "AMZN",
        "META",
        "AVGO",
        "ADBE",
        "CRM",
        "ASML",
        "AMD",
        "TSM",
        "QCOM",
        "INTC",
        "MU",
        "ORCL",
        "NOW",
        "SNOW",
        "DDOG",
        "MDB",
        "PANW",
        "CRWD",
        "ZS",
        "FTNT",
        "NET",
        "V",
        "MA",
        "PYPL",
        "FISV",
        "FIS",
        "EQIX",
        "DLR",
        "AMT",
        "CCI",
        "CSCO",
        "SHOP",
        "UBER",
        "SPOT",
        "MELI",
        "SE"
      ]
    }
  },
  "qaoa": {
    "best_bitstring": "0110011111100000",
    "betas": [
      0.629176985846273,
      0.5849285092917567,
      0.5584229740043618,
      0.24761573273221377
    ],
    "gammas": [
      -1.4154384446418264,
      -2.4535992134821565,
      -3.6575221870942647,
      -4.351972838083933
    ],
    "layers": 4,
    "qaoa_mode": "qaoa_lightning_sim",
    "qaoa_shots": null,
    "qaoa_shots_display": "exact",
    "shots_mode": "exact",
    "simulation_backend": "lightning.qubit"
  },
  "runtime_settings": {
    "effective_settings": {
      "budget_lambda": 50,
      "export_mode": "qiskit_export",
      "export_mode_label": "Qiskit simulation",
      "hardware_replay": false,
      "ibm_external_run_requested": false,
      "iterations": 60,
      "lambda_budget": 50,
      "lambda_variance": 6,
      "layers": 4,
      "legacy_run_mode_alias": false,
      "mode": "qaoa_lightning_sim",
      "qaoa_layerwise_warm_start": true,
      "qaoa_maxiter": 60,
      "qaoa_multistart_restarts": 2,
      "qaoa_p": 4,
      "qaoa_restart_perturbation": 0.05,
      "qaoa_shots": null,
      "qaoa_shots_display": "exact",
      "qiskit_export_requested": true,
      "random_seed": 42,
      "requested_run_mode": "qaoa_lightning_sim",
      "response_level": "full",
      "restart_perturbation": 0.05,
      "restarts": 2,
      "risk_free_rate": 0.04,
      "risk_lambda": 6,
      "rng_seed": 42,
      "run_mode": "qaoa_lightning_sim",
      "shots_mode": "exact",
      "simulation_backend": "lightning.qubit",
      "sources": {
        "export_mode": "form",
        "iterations": "form",
        "lambda_budget": "form",
        "lambda_variance": "form",
        "layers": "form",
        "qaoa_shots": "form",
        "random_seed": "form",
        "restart_perturbation": "form",
        "restarts": "form",
        "risk_free_rate": "form",
        "warm_start": "form"
      },
      "variance_lambda": 6,
      "warm_start": true
    },
    "iterations": 60,
    "layers": 4,
    "qaoa_shots": null,
    "qaoa_shots_display": "exact",
    "random_seed": 42,
    "restarts": 2,
    "shots_mode": "exact",
    "warm_start": true
  },
  "schema": "qaoa-rqp-code-export-package",
  "schema_version": 1,
  "type_budgets": [],
  "use_case": {
    "additional_type_constraints_count": 0,
    "budget_usd": 3200000,
    "fixed_positions": 24,
    "lambda_budget": 50,
    "lambda_variance": 6,
    "mode": "qaoa_lightning_sim",
    "n_qubits": 16,
    "risk_free_rate": 0.04,
    "solver": "classical_heuristic+qaoa_lightning_sim",
    "source": "pre-optimized Excel workbook",
    "variable_positions": 16,
    "workbook_summary": {
      "additional_type_constraints": [],
      "additional_type_constraints_count": 0,
      "assets_referenced_by_options": 40,
      "budget": 3200000,
      "cost_column_internal": "Indicative Market Cost USD",
      "cost_column_normalized": false,
      "cost_column_used": "Indicative Market Cost USD",
      "currency_code": "USD",
      "decision_state_space": "2^16 = 65,536 bitstrings",
      "decision_variables": 16,
      "fixed_asset_blocks": 24,
      "fixed_invested_amount": 2400973.236152649,
      "ignored_output_sheets": [],
      "input_sheet_names": [
        "ReadMe",
        "Assets",
        "AnnualizedCovariance",
        "Settings"
      ],
      "n_qubits": 16,
      "qubo_shape": [
        16,
        16
      ],
      "settings_count": 36,
      "unique_tickers": 40,
      "variable_asset_blocks": 16,
      "variable_candidate_universe": 1598477.1932868958
    }
  }
}
''')


# Cell purpose: reconstruct the selected full portfolio and report financial metrics.
# These helpers are framework-neutral and are reused by the Qiskit, PennyLane, and Cirq cells.
import math
import time
import numpy as np


def _package_asset_rows(package, key):
    assets = package.get("assets", {}) or {}
    if key in assets:
        return list(assets.get(key) or [])
    if key == "variable_assets":
        return list(package.get("decision_variables") or [])
    return []


def _as_float(value, default=0.0):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(result):
        return default
    return result


def _as_int(value, default=None):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _fmt_money(value):
    return f"{_as_float(value):,.0f}"


def _fmt_decimal(value, digits=6):
    value = _as_float(value, float("nan"))
    if not math.isfinite(value):
        return "n/a"
    return f"{value:.{digits}g}"


def _fmt_pct(value):
    value = _as_float(value, float("nan"))
    if not math.isfinite(value):
        return "n/a"
    return f"{100.0 * value:.3f}%"


def _short(value, width=28):
    text = "" if value is None else str(value)
    return text if len(text) <= width else text[: max(width - 1, 1)] + "..."


def _bitstring_bits(bitstring, n_qubits):
    if bitstring is None:
        return "0" * int(n_qubits)
    text = "".join(ch for ch in str(bitstring).strip() if ch in "01")
    if len(text) < int(n_qubits):
        text = text.ljust(int(n_qubits), "0")
    return text[: int(n_qubits)]


def reconstructed_qubo_value(package, bitstring):
    """Reconstruct the optimizer QUBO objective from exported Ising terms."""
    n_qubits = int((package.get("use_case") or {}).get("n_qubits") or 0)
    bits = _bitstring_bits(bitstring, n_qubits)
    z_values = np.asarray([1.0 - 2.0 * int(bit) for bit in bits], dtype=float)
    ising = package.get("ising") or {}
    h_terms = np.asarray(ising.get("h_terms") or [], dtype=float)
    if len(h_terms) < n_qubits:
        h_terms = np.pad(h_terms, (0, n_qubits - len(h_terms)))
    total = _as_float(ising.get("offset"))
    total += float(np.dot(h_terms[:n_qubits], z_values))
    for term in ising.get("j_terms") or []:
        if len(term) < 3:
            continue
        i = _as_int(term[0], -1)
        j = _as_int(term[1], -1)
        coeff = _as_float(term[2])
        if 0 <= i < n_qubits and 0 <= j < n_qubits:
            total += coeff * float(z_values[i]) * float(z_values[j])
    return float(total)


def _candidate_scope_limit(package, available_count):
    available = max(0, int(available_count or 0))
    if available == 0:
        return 0
    qaoa = package.get("qaoa") or {}
    max_export_rows = _as_int(qaoa.get("max_export_rows"), None)
    qaoa_shots = _as_int(qaoa.get("qaoa_shots"), None)
    limit = max_export_rows if max_export_rows and max_export_rows > 0 else 5000
    if qaoa_shots and qaoa_shots > 0:
        limit = min(limit, qaoa_shots)
    return max(1, min(int(limit), available))


def _candidate_display_limit(package, available_count):
    return max(1, min(10, int(available_count or 0)))


def candidate_views_from_probabilities(package, probability_items):
    n_qubits = int((package.get("use_case") or {}).get("n_qubits") or 0)
    rows = []
    for bitstring, probability in probability_items:
        normalized_bitstring = _bitstring_bits(bitstring, n_qubits)
        rows.append(
            {
                "bitstring": normalized_bitstring,
                "probability": _as_float(probability),
                "qubo_value": reconstructed_qubo_value(package, normalized_bitstring),
            }
        )

    rows_by_probability = sorted(
        rows,
        key=lambda row: (row["probability"], -row["qubo_value"]),
        reverse=True,
    )
    scope_limit = _candidate_scope_limit(package, len(rows_by_probability))
    candidate_pool = rows_by_probability[:scope_limit]
    display_limit = _candidate_display_limit(package, len(candidate_pool))
    top_probability = candidate_pool[:display_limit]
    top_qubo = sorted(
        candidate_pool,
        key=lambda row: (row["qubo_value"], -row["probability"], row["bitstring"]),
    )[:display_limit]
    return candidate_pool, top_probability, top_qubo


def print_candidate_table(title, rows):
    print(f"\n{title}")
    if not rows:
        print("  No candidates available.")
        return
    print("Rank  Bitstring                             Probability       QUBO value")
    for rank, row in enumerate(rows, start=1):
        print(
            f"{rank:>4d}  "
            f"{_short(row.get('bitstring'), 35):35s} "
            f"{_fmt_decimal(row.get('probability'), 8):>12s} "
            f"{_fmt_decimal(row.get('qubo_value'), 8):>16s}"
        )


def selected_full_portfolio(package, bitstring):
    n_qubits = int((package.get("use_case") or {}).get("n_qubits") or 0)
    bits = _bitstring_bits(bitstring, n_qubits)
    fixed_rows = [dict(row, selected=True, bit="-") for row in _package_asset_rows(package, "fixed_assets")]
    variable_rows = []
    for idx, row in enumerate(_package_asset_rows(package, "variable_assets")):
        bit = bits[idx] if idx < len(bits) else "0"
        if bit == "1":
            variable_rows.append(dict(row, selected=True, bit=bit))
    return fixed_rows + variable_rows


def _covariance_lookup(package):
    covariance = ((package.get("market_data") or {}).get("covariance") or {})
    tickers = [str(ticker) for ticker in covariance.get("tickers") or []]
    matrix = covariance.get("matrix") or []
    return {
        (row_ticker, col_ticker): _as_float(matrix[i][j])
        for i, row_ticker in enumerate(tickers)
        for j, col_ticker in enumerate(tickers)
        if i < len(matrix) and j < len(matrix[i])
    }


def _asset_cost(row):
    return _as_float(row.get("indicative_market_cost_usd"))


def _asset_return(row):
    return _as_float(row.get("expected_return_proxy"))


def _asset_vol(row):
    return _as_float(row.get("annual_volatility"))


def _asset_ticker(row):
    return str(row.get("ticker") or "")


def _asset_type_size(row, size_column):
    type_sizes = row.get("type_sizes") or {}
    return _as_float(type_sizes.get(size_column))


def portfolio_metrics(package, bitstring):
    use_case = package.get("use_case") or {}
    budget = _as_float(use_case.get("budget_usd"))
    risk_free = _as_float(use_case.get("risk_free_rate"))
    assets = selected_full_portfolio(package, bitstring)
    fixed_usd = sum(_asset_cost(row) for row in assets if row.get("role") == "fixed")
    variable_usd = sum(_asset_cost(row) for row in assets if row.get("role") != "fixed")
    invested = fixed_usd + variable_usd
    costs = np.asarray([_asset_cost(row) for row in assets], dtype=float)
    returns = np.asarray([_asset_return(row) for row in assets], dtype=float)
    cov_lookup = _covariance_lookup(package)
    cov = np.zeros((len(assets), len(assets)), dtype=float)
    for i, row_i in enumerate(assets):
        for j, row_j in enumerate(assets):
            key = (_asset_ticker(row_i), _asset_ticker(row_j))
            if key in cov_lookup:
                cov[i, j] = cov_lookup[key]
            elif i == j:
                cov[i, j] = _asset_vol(row_i) ** 2

    if invested > 0.0 and len(assets):
        weights = costs / invested
        portfolio_return = float(weights @ returns)
        portfolio_var = float(weights @ cov @ weights) if len(cov) else 0.0
        portfolio_vol = math.sqrt(max(portfolio_var, 0.0))
        sharpe_like = (
            float("nan")
            if portfolio_vol == 0.0
            else float((portfolio_return - risk_free) / portfolio_vol)
        )
    else:
        portfolio_return = 0.0
        portfolio_vol = 0.0
        sharpe_like = float("nan")

    if budget > 0.0 and len(assets):
        budget_weights = costs / budget
        cash_weight = 1.0 - invested / budget
        budget_return = float(budget_weights @ returns + cash_weight * risk_free)
        budget_var = float(budget_weights @ cov @ budget_weights) if len(cov) else 0.0
        budget_vol = math.sqrt(max(budget_var, 0.0))
        budget_sharpe = (
            float("nan")
            if budget_vol == 0.0
            else float((budget_return - risk_free) / budget_vol)
        )
    else:
        cash_weight = float("nan")
        budget_return = float("nan")
        budget_vol = float("nan")
        budget_sharpe = float("nan")

    type_budget_rows = []
    for constraint in package.get("type_budgets") or []:
        if not constraint.get("active", True):
            continue
        size_column = constraint.get("size_column")
        target = _as_float(constraint.get("budget"))
        fixed_exposure = sum(
            _asset_type_size(row, size_column) for row in assets if row.get("role") == "fixed"
        )
        variable_exposure = sum(
            _asset_type_size(row, size_column) for row in assets if row.get("role") != "fixed"
        )
        achieved = fixed_exposure + variable_exposure
        type_budget_rows.append(
            {
                "label": constraint.get("label") or constraint.get("name") or size_column,
                "size_column": size_column,
                "budget": target,
                "fixed_exposure": fixed_exposure,
                "variable_exposure": variable_exposure,
                "achieved": achieved,
                "deviation": achieved - target,
                "achieved_pct": float("nan") if target == 0.0 else achieved / target,
            }
        )

    return {
        "assets": assets,
        "fixed_usd": fixed_usd,
        "variable_usd": variable_usd,
        "invested_usd": invested,
        "budget_usd": budget,
        "budget_gap": invested - budget,
        "cash_weight": cash_weight,
        "portfolio_return": portfolio_return,
        "portfolio_vol": portfolio_vol,
        "sharpe_like": sharpe_like,
        "portfolio_return_budget_normalized": budget_return,
        "portfolio_vol_budget_normalized": budget_vol,
        "sharpe_like_budget_normalized": budget_sharpe,
        "type_budgets": type_budget_rows,
    }


def print_portfolio_report(
    package,
    bitstring,
    *,
    probability=None,
    qubo_value=None,
    runtime_seconds=None,
    runtime_label="Execution runtime",
):
    report = portfolio_metrics(package, bitstring)
    print("\nSelected portfolio report")
    print("-------------------------")
    print("Bitstring:", bitstring)
    if probability is not None:
        print("Readout probability:", _fmt_decimal(probability, 8))
    if qubo_value is not None:
        print("Reconstructed QUBO objective:", _fmt_decimal(qubo_value, 8))
    if runtime_seconds is not None:
        print(f"{runtime_label}: {_fmt_decimal(runtime_seconds, 6)} seconds")
    print(f"Invested assets vs budget: {_fmt_money(report['invested_usd'])} / {_fmt_money(report['budget_usd'])}")
    print(f"Budget gap: {_fmt_money(report['budget_gap'])}")
    print(f"Full portfolio return: {_fmt_pct(report['portfolio_return'])}")
    print(f"Full portfolio volatility: {_fmt_pct(report['portfolio_vol'])}")
    print(f"Sharpe-like ratio: {_fmt_decimal(report['sharpe_like'], 6)}")
    print(f"Budget-normalized return: {_fmt_pct(report['portfolio_return_budget_normalized'])}")
    print(f"Budget-normalized volatility: {_fmt_pct(report['portfolio_vol_budget_normalized'])}")
    print(f"Budget-normalized Sharpe-like ratio: {_fmt_decimal(report['sharpe_like_budget_normalized'], 6)}")

    if report["type_budgets"]:
        print("\nSubtype budgets")
        print("Label                         Achieved       Budget       Deviation     Achieved %")
        for row in report["type_budgets"]:
            print(
                f"{_short(row['label'], 28):28s} "
                f"{_fmt_money(row['achieved']):>12s} "
                f"{_fmt_money(row['budget']):>12s} "
                f"{_fmt_money(row['deviation']):>12s} "
                f"{_fmt_pct(row['achieved_pct']):>10s}"
            )

    print("\nSelected full portfolio")
    print("Role      Bit  Ticker        Cost USD     Return    Vol       Label")
    for row in report["assets"]:
        print(
            f"{_short(row.get('role'), 9):9s} "
            f"{str(row.get('bit', '-')):>3s} "
            f"{_short(row.get('ticker'), 11):11s} "
            f"{_fmt_money(_asset_cost(row)):>12s} "
            f"{_fmt_pct(_asset_return(row)):>8s} "
            f"{_fmt_pct(_asset_vol(row)):>8s} "
            f"{_short(row.get('option_label') or row.get('company'), 36)}"
        )
    return report


def plot_portfolio_summary(package, report):
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print("Plot skipped:", type(exc).__name__, exc)
        return

    labels = ["Fixed", "Variable"]
    values = [report.get("fixed_usd", 0.0), report.get("variable_usd", 0.0)]
    cash = report.get("budget_usd", 0.0) - report.get("invested_usd", 0.0)
    if abs(cash) > 1e-9:
        labels.append("Cash / gap")
        values.append(cash)

    has_type_budgets = bool(report.get("type_budgets"))
    fig_width = 11 if has_type_budgets else 6
    fig, axes = plt.subplots(1, 2 if has_type_budgets else 1, figsize=(fig_width, 4))
    if not isinstance(axes, np.ndarray):
        axes = np.asarray([axes])

    axes[0].bar(labels, values, color=["#64748b", "#2563eb", "#f59e0b"][: len(labels)])
    axes[0].set_title("Invested assets vs budget")
    axes[0].set_ylabel("USD")
    axes[0].tick_params(axis="x", rotation=20)

    if has_type_budgets:
        type_labels = [_short(row["label"], 18) for row in report["type_budgets"]]
        achieved = [row["achieved"] for row in report["type_budgets"]]
        budgets = [row["budget"] for row in report["type_budgets"]]
        x = np.arange(len(type_labels))
        width = 0.38
        axes[1].bar(x - width / 2, achieved, width, label="Achieved", color="#2563eb")
        axes[1].bar(x + width / 2, budgets, width, label="Budget", color="#94a3b8")
        axes[1].set_title("Subtype budgets")
        axes[1].set_xticks(x, type_labels, rotation=20, ha="right")
        axes[1].legend()

    fig.tight_layout()
    backend = str(plt.get_backend()).lower()
    if "agg" in backend:
        print("Plot created with a non-interactive backend. Use fig.savefig(...) if you want to persist it.")
        plt.close(fig)
    else:
        plt.show()
    return fig

# Cell purpose: build the optimized QAOA circuit in Qiskit from exported Ising terms and angles.
import numpy as np
from qiskit import QuantumCircuit, transpile


def optimizer_bitstring_from_qiskit_key(key, n_qubits=None):
    """Convert Qiskit's cN-1...c0 key order into optimizer q0...qN-1 order."""
    bitstring = str(key).replace(" ", "")
    if n_qubits is not None:
        bitstring = bitstring.zfill(int(n_qubits))[-int(n_qubits):]
    return bitstring[::-1]


def build_qaoa_circuit(package, measure=False):
    use_case = package["use_case"]
    qaoa = package["qaoa"]
    ising = package["ising"]
    n_qubits = int(use_case["n_qubits"])
    gammas = np.asarray(qaoa["gammas"], dtype=float)
    betas = np.asarray(qaoa["betas"], dtype=float)
    h_terms = np.asarray(ising["h_terms"], dtype=float)
    j_terms = [(int(i), int(j), float(coeff)) for i, j, coeff in ising["j_terms"]]

    qc = QuantumCircuit(n_qubits, n_qubits if measure else 0)
    for wire in range(n_qubits):
        qc.h(wire)

    for gamma, beta in zip(gammas, betas):
        for wire, coeff in enumerate(h_terms):
            if abs(float(coeff)) > 1e-12:
                qc.rz(2.0 * float(gamma) * float(coeff), wire)
        for control, target, coeff in j_terms:
            if abs(float(coeff)) > 1e-12:
                qc.cx(control, target)
                qc.rz(2.0 * float(gamma) * float(coeff), target)
                qc.cx(control, target)
        for wire in range(n_qubits):
            qc.rx(2.0 * float(beta), wire)

    if measure:
        qc.measure(range(n_qubits), range(n_qubits))
    return qc


def print_circuit_summary(qc, measured=None, transpiled=None, draw_qubit_limit=8):
    print(
        f"QAOA circuit: {qc.num_qubits} qubits, "
        f"depth={qc.depth()}, operations={sum(qc.count_ops().values())}"
    )
    print("Gate counts:", dict(qc.count_ops()))
    if measured is not None:
        print("Measured depth:", measured.depth())
    if transpiled is not None:
        print("Transpiled depth:", transpiled.depth())
        print("Transpiled gate counts:", dict(transpiled.count_ops()))
    if qc.num_qubits <= draw_qubit_limit:
        print(qc)
    else:
        print(
            f"Full text circuit diagram skipped for {qc.num_qubits} qubits. "
            f"Call qc.draw('text', fold=120) manually if you want the full diagram."
        )

from qiskit.quantum_info import Statevector


def main():
    qc = build_qaoa_circuit(PACKAGE, measure=False)
    qc_measured = build_qaoa_circuit(PACKAGE, measure=True)
    transpiled = transpile(qc_measured, optimization_level=1)
    print_circuit_summary(qc, qc_measured, transpiled)
    readout_start = time.perf_counter()
    state = Statevector.from_instruction(qc)
    probabilities = state.probabilities_dict()
    readout_runtime_seconds = time.perf_counter() - readout_start
    n_qubits = int(PACKAGE["use_case"]["n_qubits"])
    probability_items = [
        (optimizer_bitstring_from_qiskit_key(key, n_qubits), float(probability))
        for key, probability in probabilities.items()
    ]
    candidate_pool, top_probability_rows, top_qubo_rows = candidate_views_from_probabilities(PACKAGE, probability_items)
    print("Best bitstring from QAOA RQP:", PACKAGE["qaoa"].get("best_bitstring"))
    print(f"Candidate comparison pool: {len(candidate_pool)} states capped by shots/max candidates when available.")
    print_candidate_table("Top simulated states by probability", top_probability_rows)
    print_candidate_table("Top simulated states by reconstructed QUBO objective", top_qubo_rows)
    selected_row = top_probability_rows[0] if top_probability_rows else {}
    selected_bitstring = selected_row.get("bitstring") or PACKAGE["qaoa"].get("best_bitstring")
    selected_probability = selected_row.get("probability")
    selected_qubo_value = selected_row.get("qubo_value")
    report = print_portfolio_report(
        PACKAGE,
        selected_bitstring,
        probability=selected_probability,
        qubo_value=selected_qubo_value,
        runtime_seconds=readout_runtime_seconds,
        runtime_label="Qiskit statevector readout runtime",
    )
    _ = plot_portfolio_summary(PACKAGE, report)


if __name__ == "__main__":
    main()
